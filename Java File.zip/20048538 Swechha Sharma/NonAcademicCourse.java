
/**
 * Write a description of class NonAcademicCourse here.
 *
 * @author (Swechha Sharma)
 * @version (2021-05-18)
 */
//Creating NonAcademic Course
public class NonAcademicCourse extends Course{
    // instance variables
    private String InstructorName;
    private int Duration;
    private String StartDate;
    private String CompletionDate;
    private String ExamDate;
    private String Prerequisite;
    private boolean isRegistered;
    private boolean isRemoved;
    //creating constructor with parameters
    public NonAcademicCourse(String CourseID,String CourseName,int Duration,String Prerequisite)
    {// initialise instance variables
        super(CourseID,CourseName,Duration);
        this.InstructorName="";
        this.StartDate="";
        this.CompletionDate="";
        this.ExamDate="";
        this.Prerequisite=Prerequisite;
        this.Duration=25;
        this.isRegistered=false;
        this.isRemoved=false;
    }//Getter method- accessor and setter methos- mutator method
    public String getInstructorName(){
        return InstructorName;
    }
    public String getStartDate(){
        return StartDate;
    }
    public int getDuration(){
        return Duration;
    }
    public String getCompletionDate(){
        return CompletionDate;
    }
    public String getExamDate(){
        return ExamDate;
    }
    public void setInstructorName(String NewInstructor){
        if(this.isRegistered==false){
        this.InstructorName= NewInstructor;
    }
        else{
        System.out.println("The Non-Academic Course is already registered successfully");
    }
    }
    public boolean getisRemoved(){
        return isRemoved;
    }
    public boolean getisRegistered(){
        return isRegistered;
    }
    public String getPrerequisite(){
        return Prerequisite;
    }  
    public void register(String CourseLeader,String InstructorName,String StartDate,String CompletionDate,String ExamDate){
        if(this.isRegistered==false){
            super.SetCourseLeader(CourseLeader);
            this.InstructorName=(InstructorName);
            this.Duration=Duration;
            this.StartDate=StartDate;
            this.CompletionDate=CompletionDate;
            this.ExamDate=ExamDate;
            this.isRegistered=true;
        }
        else{
            System.out.println("The Course is already registered successfully");
        }
    }
    public void Remove(){
        if(isRemoved==true){
            System.out.println("The Instructor is removed for this Module");
        }
        else{
            super.SetCourseLeader("");
            this.InstructorName="";
            this.StartDate="";
            this.ExamDate="";
            this.CompletionDate="";
            this.isRegistered=false;
            this.isRemoved=true;
        }
    } // method to display the output
    public void Display(){
        super.Display();
        if (isRegistered==true){
            System.out.println("The Instructor of Non Academic Course is"+getInstructorName());
            System.out.println("The StartDate of Non Academic Course is"+getStartDate());
            System.out.println("The ExamDate of Non Academic Course is"+getExamDate());
            System.out.println("The CompletionDate of Non Academic Course is"+getCompletionDate());
        }
        else{
            System.out.println("The Non-Academic Course is already registered successfully");
        }
    }
}//Class Closed
