
/**
 * Write a description of class Course here.
 *
 * @author (Swechha Sharma)
 * @version (2021-05-17)
 */
//Creating Course Class
public class Course{
    // instance variables
    private String CourseID;
    private String CourseName;
    private int Duration;
    private String CourseLeader;
    //creating constructor with parameters
    public Course(String CourseID,String CourseName,int Duration){
        // initialise instance variables
        this.CourseID=CourseID;
        this.CourseName=CourseName;
        this.Duration=Duration;
        this.CourseLeader="";
    }//Getter method - accessor and setter method - mutator method
    public void SetCourseLeader(String newName){
        this.CourseLeader = newName;
    }
    public String getCourseID(){
        return CourseID;
    }
    public String getCourseName(){
        return CourseName;
    }
    public int getDuration(){
        return Duration;
    }
    public String getCourseLeader(){
        return CourseLeader;
    }//method to display the output
    public void Display(){
        System.out.println("The CourseID of this Module is" + getCourseID());
        System.out.println("The CourseName of this Module is" + getCourseName());
        System.out.println("The Duration for this Module is" + getDuration());
        if(this.CourseLeader!=(CourseLeader)){
            System.out.println("The CourseLeader of this Module is" +getCourseLeader());
            
        }
    }
} //Class Closed

