
/**
 * Write a description of class AcademicCourse here.
 *
 * @author (Swechha Sharma)
 * @version (2021-05-17)
 */
//Creating AcademicCourse Class
public class AcademicCourse extends Course{
    // instance variables
    private String LecturerName;
    private String Level;
    private String Credit;
    private String StartingDate;
    private String CompletionDate;
    private int NumberofAssessment;
    private boolean isRegistered;
    //creating constructor with parameters
    public AcademicCourse(String CourseID,String CourseName,int Duration,String Level,String Credit,int NumberofAssessment){
    // initialise instance variables
        super(CourseID,CourseName,Duration);
        this.NumberofAssessment=NumberofAssessment;
        this.Level=Level;
        this.Credit=Credit;
        this.LecturerName="";
        this.StartingDate="";
        this.CompletionDate="";
        this. isRegistered=false;
    }//Getter method - accessor and setter method - mutator method 
    public int getNumberofAssessment(){
        return NumberofAssessment;
    }
    public String getLecturerName(){
        return LecturerName;
    }
    public String getLevel(){
        return Level;
    }
    public String getCredit(){
        return Credit;
    }
    public String getStartingDate(){
        return StartingDate;
    }
    public String getCompletionDate(){
        return CompletionDate;
    }
    public boolean getisRegistered(){
        return isRegistered;
    }
    public void setLecturerName(String newLecturerName){
        this.LecturerName= newLecturerName;
    }
    public void setNumberofAssessment(int newNumberofAssessment){
        this.NumberofAssessment= NumberofAssessment;
    }
    public void Register(String LeaderName,String LecturerName,String StartingDate,String CompletionDate){
        if(isRegistered==true){
            System.out.println("Academic Course has already been registered");
            System.out.println("The Lecturer name is"+this.getLecturerName());
            System.out.println("The Starting date is"+this.getStartingDate());
            System.out.println("The Completion date is"+this.getCompletionDate());
        }
        else{
            super.SetCourseLeader(LeaderName);
            this.LecturerName=LecturerName;
            this.StartingDate=StartingDate;
            this.CompletionDate=CompletionDate;
            isRegistered=true;
            System.out.println("The Course has been already registered");
        }
    }//method to display output
    public void Display(){
        super.Display();
        if (isRegistered==true){
            System.out.println("The Course Lecturer name of Academic Course is"+ this.getLecturerName());
            System.out.println("The Course Level of Academic Course is"+ this.getLevel());
            System.out.println("The Course Credit of Academic Course is"+ this.getCredit());
            System.out.println("The Course Starting Date of Academic Course is"+ this.getStartingDate());
            System.out.println("The Course Completion Date of Academic Course is"+ this.getCompletionDate());
            System.out.println("The Course Number of Assessment of Academic Course is"+ this.getNumberofAssessment());
        }
    
    }
}//Class Closed
